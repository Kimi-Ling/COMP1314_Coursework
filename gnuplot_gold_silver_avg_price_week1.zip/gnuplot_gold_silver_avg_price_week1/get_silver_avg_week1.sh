#!/bin/bash

# Get gold daily average price
awk '{
        day=$1; sum[day]+=$3; n[day]++
}
END { for(d in sum) print d, sum[d]/n[d] }' \
silver_week1_clean.txt | sort > silver_price_daily_avg.txt
