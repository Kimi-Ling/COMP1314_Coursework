#!/bin/bash

# Combine two file into a file
paste gold_price_daily_avg_week2.txt silver_price_daily_avg_week2.txt > combine_daily_avg_week2.txt

# Avoid two timestamp

awk '{
	print $1, $2, $4
}' combine_daily_avg_week2.txt > final_daily_avg_week2.txt

# Plot histogram graph
gnuplot <<EOF
set terminal png size 800, 600 font 'Arial'
set style data histograms
set style histogram clustered gap 1
set style fill solid 1.0 border -1
set boxwidth 0.8
set output 'week2_daily_average_gold_silver_price.png'
set xlabel 'Date'
set ylabel 'Average Price (USD)'
set grid ytics
set title 'Gold VS Silver Average Prices - Week 2'
set grid
plot "final_daily_avg_week2.txt" using 2:xtic(1) title "Gold", \
"" using 3 title "Silver"

EOF
