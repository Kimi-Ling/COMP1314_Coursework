#!/bin/bash

# Grep the week in seperate two weeks
# Week 1
grep -E '2025-12-08|2025-12-09|2025-12-10|2025-12-11|2025-12-12' gold_all_clean.txt > gold_week2_clean.txt

# Plot week 1
gnuplot <<EOF
set terminal png size 800, 600 font 'Arial'
set output 'week2_goldprice.png'
set xlabel 'Date & Time'
set xdata time
set timefmt "%Y-%m-%d %H:%M:%S"
set format x "%m-%d\n%H:%M"
set ylabel 'Price (USD)'
set title 'Gold Prices - Week 2'
set grid
plot "gold_week2_clean.txt" using 1:3 with lines title "Gold"
EOF
