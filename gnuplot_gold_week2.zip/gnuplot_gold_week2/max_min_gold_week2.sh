#!/bin/bash

gnuplot << EOF
set terminal png size 800, 600 font 'Arial'
set output 'week2_max_min_goldprice.png'
set xlabel 'Date & Time'
set xdata time
set timefmt "%Y-%m-%d %H:%M:%S"
set format x "%m-%d\n%H:%M"
set ylabel 'Price (USD)'
set title 'Daily Max and Min Gold Prices - Week 2'
set grid
plot "max_min_week2_daily.txt" using 1:2 with linespoints ls 1 title "Max Gold", \
     "max_min_week2_daily.txt" using 1:3 with linespoints ls 2 title "Min Gold"
EOF
