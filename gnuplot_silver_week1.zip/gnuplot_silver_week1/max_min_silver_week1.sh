#!/bin/bash

gnuplot << EOF
set terminal png size 800, 600 font 'Arial'
set output 'week1_max_min_silverprice.png'
set xlabel 'Date & Time'
set xdata time
set timefmt "%d-%m-%Y %H:%M:%S"
set format x "%d-%m\n%H:%M"
set ylabel 'Price (USD)'
set title 'Daily Max and Min Silver Prices - Week 1'
set grid
plot "max_min_week1_daily_silver.txt" using 1:2 with linespoints ls 1 title "Max Silver", \
     "max_min_week1_daily_silver.txt" using 1:3 with linespoints ls 2 title "Min Silver"
EOF
