#!/bin/bash

# Grep the week in seperate two weeks - Week 1:
grep -E '2025-12-08|2025-12-09|2025-12-10|2025-12-11|2025-12-12' silver_all_clean.txt > silver_week2_clean.txt

# Plot week 2
gnuplot <<EOF
set terminal png size 800, 600 font 'Arial'
set output 'week2_silverprice.png'
set xlabel 'Date & Time'
set xdata time
set timefmt "%Y-%m-%d %H:%M:%S"
set format x "%m-%d\n%H:%M"
set ylabel 'Price (USD)'
set title 'Silver Prices - Week 2'
set grid
plot "silver_week2_clean.txt" using 1:3 with lines title "Silver"
EOF
